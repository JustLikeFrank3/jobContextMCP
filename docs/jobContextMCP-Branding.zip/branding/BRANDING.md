
# JobContextMCP Branding

This document describes the branding assets for JobContextMCP.

## Logos
- branding/logo/jobcontextmcp-mark.svg / .png
- branding/logo/jobcontextmcp-mark-dark.svg / .png

## Banner
- branding/banner/jobcontextmcp-readme.svg / .png

## Favicons
- branding/favicon/favicon-32.png
- branding/favicon/favicon-16.png

## Copilot instructions
Use these files for README headers, terminal banners, MCP client icons, and favicons.
